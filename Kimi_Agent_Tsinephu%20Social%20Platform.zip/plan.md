# Tsinephu Mega-Update Plan

## Stage 1 — Language Fix (COMPLETED)
- Fixed ancient/living language categorization by using explicit language codes instead of flag-based filtering
- Armenian (hy), Turkish (tr), Persian (fa), Greek (el), Norwegian (no) now correctly show as living
- Talysh (tly) and Luri (lrc) now correctly show as living

## Stage 2 — Parallel Work Streams

### Workstream A: Theme System + Security + Sepia/Lecture Modes
**Skill**: webapp-building
**Agent**: theme_security_agent
**Files to modify**:
- `/mnt/agents/output/app/src/types/index.ts` — Add 'sepia' | 'lecture' to Theme type
- `/mnt/agents/output/app/src/context/ThemeContext.tsx` — Full rewrite for 4 themes
- `/mnt/agents/output/app/src/index.css` — Add sepia and lecture CSS variables
- `/mnt/agents/output/app/src/pages/SettingsPage.tsx` — Add theme selector UI
- `/mnt/agents/output/app/src/context/AuthContext.tsx` — Security improvements (rate limiting, input sanitization, stronger hashing)

### Workstream B: Code Parniks Feature (MAJOR NEW FEATURE)
**Skill**: webapp-building
**Agent**: code_parniks_agent
**Files to create/modify**:
- `/mnt/agents/output/app/src/types/index.ts` — Add codeData: { html: string; css: string; js: string; title: string; lang: string } to Parnik
- `/mnt/agents/output/app/src/context/ParnikContext.tsx` — Add createCodeParnik, forkCodeParnik methods
- `/mnt/agents/output/app/src/components/ComposeModal.tsx` — Add code editor tab with HTML/CSS/JS editors (up to 2000 lines)
- `/mnt/agents/output/app/src/components/CodePreview.tsx` — NEW: iframe-based code preview component
- `/mnt/agents/output/app/src/components/ParnikCard.tsx` — Add code preview rendering with fork button
- `/mnt/agents/output/app/src/components/CodeEditor.tsx` — NEW: syntax-highlighted code editor with line numbers

### Workstream C: Map Parniks Improvements
**Skill**: webapp-building
**Agent**: map_parniks_agent
**Files to modify**:
- `/mnt/agents/output/app/src/components/MapParnikDrawer.tsx` — Add satellite view, measurement tools, undo/redo, layer management
- `/mnt/agents/output/app/src/components/ComposeModal.tsx` — Improved map integration

### Workstream D: Language Translation Improvements
**Agent**: language_agent
**Files to modify**:
- `/mnt/agents/output/app/src/context/LanguageContext.tsx` — Improve translations for hy, tr, fa, el, no, kw, tly, lrc

## Stage 3 — Integration
- Reconfigure App.tsx for all new features
- Build and verify
- Deploy
